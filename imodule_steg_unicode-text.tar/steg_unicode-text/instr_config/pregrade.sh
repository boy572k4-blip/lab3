#!/bin/bash
: <<'END'
This software was created by United States Government employees at 
The Center for Cybersecurity and Cyber Operations (C3O) 
at the Naval Postgraduate School NPS.  Please note that within the 
United States, copyright protection is not available for any works 
created  by United States Government employees, pursuant to Title 17 
United States Code Section 105.   This software is in the public 
domain and is not subject to copyright. 
END
#
# pregrade.sh - chạy trước khi grade bài lab steg_unicode-text
#
MYHOME=$1
DEST=$2

mkdir -p "$MYHOME/$DEST/.local/result"
