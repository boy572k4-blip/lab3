#!/bin/bash
REGISTRY="r3xonx"
LAB="steg_unicode-text"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=============================================="
echo " Build & Push: $LAB"
echo " $REGISTRY/${LAB}.writer.student"
echo " $REGISTRY/${LAB}.reader.student"
echo "=============================================="

docker login -u "$REGISTRY"
[ $? -ne 0 ] && echo "[ERROR] Login thất bại!" && exit 1

echo "[BUILD] writer..."
cd "$SCRIPT_DIR/writer" && docker build -t "$REGISTRY/${LAB}.writer.student:latest" .
[ $? -ne 0 ] && echo "[ERROR] Build writer thất bại!" && exit 1

echo "[BUILD] reader..."
cd "$SCRIPT_DIR/reader" && docker build -t "$REGISTRY/${LAB}.reader.student:latest" .
[ $? -ne 0 ] && echo "[ERROR] Build reader thất bại!" && exit 1

echo "[PUSH] writer..."
docker push "$REGISTRY/${LAB}.writer.student:latest"
echo "[PUSH] reader..."
docker push "$REGISTRY/${LAB}.reader.student:latest"

echo "=============================================="
echo " HOÀN THÀNH!"
echo "=============================================="
