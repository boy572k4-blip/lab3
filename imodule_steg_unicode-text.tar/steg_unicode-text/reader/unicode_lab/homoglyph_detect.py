#!/usr/bin/env python3
"""
Unicode Homoglyph Detector - Phát hiện ký tự Cyrillic/Greek giả mạo Latin
"""
import argparse
import unicodedata

# Ký tự thường bị dùng làm homoglyph (trông giống Latin nhưng là Cyrillic/Greek)
KNOWN_HOMOGLYPHS = {
    '\u0430': ('a', 'U+0430', 'Cyrillic small letter a'),
    '\u0435': ('e', 'U+0435', 'Cyrillic small letter ie'),
    '\u043e': ('o', 'U+043e', 'Cyrillic small letter o'),
    '\u0441': ('c', 'U+0441', 'Cyrillic small letter es'),
    '\u0440': ('p', 'U+0440', 'Cyrillic small letter er'),
    '\u0445': ('x', 'U+0445', 'Cyrillic small letter ha'),
    '\u0443': ('y', 'U+0443', 'Cyrillic small letter u'),
    '\u0456': ('i', 'U+0456', 'Cyrillic small letter byelorussian-ukrainian i'),
    # Greek
    '\u03b1': ('a', 'U+03B1', 'Greek small letter alpha'),
    '\u03bf': ('o', 'U+03BF', 'Greek small letter omicron'),
    '\u03c1': ('p', 'U+03C1', 'Greek small letter rho'),
    '\u03ba': ('k', 'U+03BA', 'Greek small letter kappa'),
    '\u03bd': ('v', 'U+03BD', 'Greek small letter nu'),
}

def detect_homoglyphs(text):
    found = []
    for idx, ch in enumerate(text):
        if ch in KNOWN_HOMOGLYPHS:
            latin_equiv, codepoint, name = KNOWN_HOMOGLYPHS[ch]
            # Lấy ngữ cảnh xung quanh
            start = max(0, idx - 10)
            end   = min(len(text), idx + 10)
            context = repr(text[start:end])
            found.append({
                'pos': idx,
                'char': ch,
                'latin_equiv': latin_equiv,
                'codepoint': codepoint,
                'name': name,
                'context': context,
            })
    return found

def main():
    parser = argparse.ArgumentParser(description='Homoglyph Detector')
    parser.add_argument('--input',  required=True, help='File cần phân tích')
    parser.add_argument('--output', required=True, help='File kết quả report')
    args = parser.parse_args()

    with open(args.input, 'r', encoding='utf-8') as f:
        text = f.read()

    found = detect_homoglyphs(text)

    report_lines = []
    report_lines.append(f"[HOMOGLYPH DETECTION REPORT]")
    report_lines.append(f"File: {args.input}")
    report_lines.append(f"Tổng ký tự phân tích: {len(text)}")
    report_lines.append(f"Số homoglyph phát hiện: {len(found)}")
    report_lines.append("=" * 50)

    if found:
        for i, item in enumerate(found):
            report_lines.append(
                f"[{i+1}] Vị trí {item['pos']:5d}: char='{item['char']}' | "
                f"Latin equiv='{item['latin_equiv']}' | {item['codepoint']} - {item['name']}"
            )
            report_lines.append(f"      Context: {item['context']}")
    else:
        report_lines.append("[OK] Không tìm thấy homoglyph đáng ngờ.")

    report = '\n'.join(report_lines)
    print(report)

    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(report + '\n')

    print(f"\n[INFO] Đã lưu report vào: {args.output}")

    # Hiển thị 3 codepoint đầu tiên để sinh viên ghi lại
    if len(found) >= 3:
        print("\n[GỢI Ý] 3 homoglyph đầu tiên:")
        for item in found[:3]:
            print(f"  {item['codepoint']} => '{item['char']}' (trông như '{item['latin_equiv']}')")

if __name__ == '__main__':
    main()
