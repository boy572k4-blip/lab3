#!/usr/bin/env python3
"""
Zero-Width Character Steganography - Trích xuất thông điệp từ văn bản
"""
import argparse
import sys

ZWSP = '\u200b'   # bit 0
ZWNJ = '\u200c'   # bit 1
DELIMITER = "$$END$$"

def extract_zwc(stego_text):
    """Trích xuất các ZWC và giải mã thông điệp."""
    bits = []
    for ch in stego_text:
        if ch == ZWSP:
            bits.append(0)
        elif ch == ZWNJ:
            bits.append(1)

    if len(bits) == 0:
        print("[WARNING] Không tìm thấy ký tự zero-width!")
        return None

    # Giải mã từng 8 bits => 1 ký tự
    text = ""
    for i in range(0, len(bits) - 7, 8):
        byte = 0
        for j in range(8):
            byte = (byte << 1) | bits[i + j]
        if byte == 0:
            break
        text += chr(byte)
        if text.endswith(DELIMITER):
            message = text[:-len(DELIMITER)]
            return message

    return None

def main():
    parser = argparse.ArgumentParser(description='ZWC Extract - Trích xuất thông điệp từ Zero-Width Characters')
    parser.add_argument('--input',  required=True, help='File stego input')
    parser.add_argument('--output', required=True, help='File output kết quả')
    args = parser.parse_args()

    with open(args.input, 'r', encoding='utf-8') as f:
        stego = f.read()

    message = extract_zwc(stego)

    if message:
        print(f"[SUCCESS] Thông điệp giải mã: '{message}'")
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(f"zwsp_message={message}\n")
        print(f"[INFO] Đã lưu vào: {args.output}")
    else:
        print("[ERROR] Không thể giải mã thông điệp.")
        sys.exit(1)

if __name__ == '__main__':
    main()
