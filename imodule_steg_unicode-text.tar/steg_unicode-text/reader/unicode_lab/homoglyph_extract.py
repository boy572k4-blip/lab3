#!/usr/bin/env python3
"""
Homoglyph Steganography - Trích xuất thông điệp từ văn bản có homoglyph
"""
import argparse
import sys

DELIMITER = "##END##"

KNOWN_HOMOGLYPHS = {
    '\u0430': 'a', '\u0435': 'e', '\u043e': 'o',
    '\u0441': 'c', '\u0440': 'p', '\u0445': 'x',
    '\u0443': 'y', '\u0456': 'i',
}
# Latin characters that are the "carrier" set (same as in embed)
CARRIER_CHARS = set('aeocpxyi')

def extract_homoglyph(stego_text):
    """Đọc từng ký tự, ghi bit 0 (Latin) hoặc 1 (Cyrillic homoglyph)."""
    bits = []
    for ch in stego_text:
        if ch in KNOWN_HOMOGLYPHS:
            bits.append(1)    # Cyrillic = bit 1
        elif ch in CARRIER_CHARS:
            bits.append(0)    # Latin = bit 0

    if len(bits) < 8:
        print("[WARNING] Không đủ bits để giải mã.")
        return None

    text = ""
    for i in range(0, len(bits) - 7, 8):
        byte = 0
        for j in range(8):
            byte = (byte << 1) | bits[i + j]
        if byte == 0:
            break
        text += chr(byte)
        if text.endswith(DELIMITER):
            return text[:-len(DELIMITER)]

    return None

def main():
    parser = argparse.ArgumentParser(description='Homoglyph Extract')
    parser.add_argument('--input',  required=True, help='File stego input')
    parser.add_argument('--output', required=True, help='File output kết quả')
    args = parser.parse_args()

    with open(args.input, 'r', encoding='utf-8') as f:
        stego = f.read()

    message = extract_homoglyph(stego)

    if message:
        print(f"[SUCCESS] Thông điệp giải mã: '{message}'")
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(f"homoglyph_message={message}\n")
        print(f"[INFO] Đã lưu vào: {args.output}")
    else:
        print("[ERROR] Không thể giải mã thông điệp.")
        sys.exit(1)

if __name__ == '__main__':
    main()
