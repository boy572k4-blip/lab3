#!/bin/bash
service ssh start 2>/dev/null

# Tạo .seed cho Labtainer grader
mkdir -p /home/ubuntu/.local
echo "steg_unicode-text_seed" > /home/ubuntu/.local/.seed
echo "student@labtainer.local" > /home/ubuntu/.local/.email
echo "steg_unicode-text" > /home/ubuntu/.local/.labname
chown -R ubuntu:ubuntu /home/ubuntu/.local

# Tạo /var/labtainer/did_param
mkdir -p /var/labtainer
touch /var/labtainer/did_param

# Tạo các file văn bản mẫu cho bài lab
mkdir -p /home/ubuntu/unicode_lab
chown -R ubuntu:ubuntu /home/ubuntu/unicode_lab
if [ ! -f /home/ubuntu/unicode_lab/cover_text.txt ]; then
    python3 /home/ubuntu/unicode_lab/generate_texts.py 2>/dev/null
    chown -R ubuntu:ubuntu /home/ubuntu/unicode_lab
fi

tail -f /dev/null
