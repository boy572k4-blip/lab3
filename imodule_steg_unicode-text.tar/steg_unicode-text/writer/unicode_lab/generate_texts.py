#!/usr/bin/env python3
"""Tạo các file văn bản mẫu cho bài lab Unicode Steganography"""
import os
import sys

STEG_DIR = '/home/ubuntu/unicode_lab'

ORIGINAL_TEXT = """\
Steganography is the practice of concealing information within ordinary, non-secret data.
Unlike cryptography which scrambles data, steganography hides its very existence.
The word comes from the Greek words steganos (covered) and graphein (to write).
Modern digital steganography can hide data in images, audio files, video, and even plain text.
Text-based steganography is particularly dangerous because it appears completely innocent.
Attackers use these techniques to exfiltrate data without triggering security alerts.
Security researchers study these methods to build better detection tools.
The challenge lies in the fact that hidden data is imperceptible to casual observers.
Open source tools like OpenStego and SilentEye implement various steganographic algorithms.
Understanding these techniques is essential for modern cybersecurity professionals.
""".replace('\n', '\n')

# Văn bản cover dùng để nhúng (nhiều space và ký tự homoglyphable)
COVER_TEXT = """\
Cybersecurity is a complex and ever-evolving field that requires constant attention.
Every organization needs to protect its assets, people, and processes from cyber attacks.
The core principles of security are confidentiality, integrity, and availability.
Penetration testers probe systems to expose weaknesses before attackers can exploit them.
Encryption protects data in transit and at rest using modern cryptographic algorithms.
Access control ensures only authorized users can read, write, or execute sensitive resources.
Security operations centers monitor activity across enterprise environments continuously.
Incident response teams analyze, contain, and remediate breaches when they occur.
Policy compliance requires organizations to adhere to regulatory frameworks and standards.
Professional certifications validate expertise in areas like networking, forensics, and red-teaming.
""".replace('\n', '\n')

# Tạo stego_zwsp.txt - bản đã nhúng sẵn bằng ZWSP để sinh viên quan sát
ZWSP = '\u200b'
ZWNJ = '\u200c'

def make_stego_zwsp(text, hidden="DEMO"):
    """Nhúng một demo message vào để sinh viên quan sát."""
    bits = []
    for ch in hidden:
        byte = ord(ch)
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    
    positions = []
    for i, ch in enumerate(text):
        if ch == ' ':
            positions.append(i + 1)
    
    result = list(text)
    insertions = []
    for idx, bit in enumerate(bits[:len(positions)]):
        zwc = ZWSP if bit == 0 else ZWNJ
        insertions.append((positions[idx], zwc))
    
    for pos, zwc in sorted(insertions, reverse=True):
        result.insert(pos, zwc)
    return ''.join(result)

# Tạo homoglyph_sample.txt - bản đã thay một số ký tự bằng Cyrillic
LATIN_TO_CYRILLIC = {
    'a': '\u0430', 'e': '\u0435', 'o': '\u043e',
    'c': '\u0441', 'p': '\u0440', 'x': '\u0445',
    'y': '\u0443',
}
SAMPLE_HOMOGLYPHS = "HIDDEN"
SAMPLE_TEXT = "Security experts analyze potential attack vectors every day."

def make_homoglyph_sample(cover, hidden="HIDDEN"):
    bits = []
    for ch in hidden:
        byte = ord(ch)
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    positions = [(i, ch) for i, ch in enumerate(cover) if ch in LATIN_TO_CYRILLIC]
    result = list(cover)
    for idx, bit in enumerate(bits[:len(positions)]):
        pos, ch = positions[idx]
        if bit == 1:
            result[pos] = LATIN_TO_CYRILLIC[ch]
    return ''.join(result)

def main():
    os.makedirs(STEG_DIR, exist_ok=True)

    # original.txt
    with open(os.path.join(STEG_DIR, 'original.txt'), 'w', encoding='utf-8') as f:
        f.write(ORIGINAL_TEXT)
    print("[OK] original.txt")

    # stego_zwsp.txt - bản đã nhúng demo
    stego = make_stego_zwsp(ORIGINAL_TEXT, "DEMO")
    with open(os.path.join(STEG_DIR, 'stego_zwsp.txt'), 'w', encoding='utf-8') as f:
        f.write(stego)
    print("[OK] stego_zwsp.txt")

    # cover_text.txt - dùng để nhúng trong bài
    with open(os.path.join(STEG_DIR, 'cover_text.txt'), 'w', encoding='utf-8') as f:
        f.write(COVER_TEXT)
    print("[OK] cover_text.txt")

    # homoglyph_sample.txt - mẫu có homoglyph để phát hiện
    sample = make_homoglyph_sample(COVER_TEXT, "HIDDEN")
    with open(os.path.join(STEG_DIR, 'homoglyph_sample.txt'), 'w', encoding='utf-8') as f:
        f.write(sample)
    print("[OK] homoglyph_sample.txt")

    print(f"\n[DONE] Tất cả file đã được tạo tại {STEG_DIR}")

if __name__ == '__main__':
    main()
