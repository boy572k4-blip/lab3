#!/usr/bin/env python3
"""
Unicode Homoglyph Steganography - Nhúng thông điệp bằng thay thế ký tự
Latin 'a','e','o','c','p','x','y' => Cyrillic tương ứng để encode bit 1
Bit 0 = giữ nguyên ký tự Latin, Bit 1 = thay bằng Cyrillic homoglyph
"""
import argparse
import sys

DELIMITER = "##END##"

# Bảng ánh xạ Latin => Cyrillic homoglyph (trông giống hệt nhau)
LATIN_TO_CYRILLIC = {
    'a': '\u0430',  # Cyrillic small letter a
    'e': '\u0435',  # Cyrillic small letter ie
    'o': '\u043e',  # Cyrillic small letter o
    'c': '\u0441',  # Cyrillic small letter es
    'p': '\u0440',  # Cyrillic small letter er
    'x': '\u0445',  # Cyrillic small letter ha
    'y': '\u0443',  # Cyrillic small letter u
    'i': '\u0456',  # Cyrillic small letter byelorussian-ukrainian i
}

def text_to_bits(text):
    bits = []
    for ch in text:
        byte = ord(ch)
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    return bits

def embed_homoglyph(cover_text, message):
    """Nhúng bits vào bằng cách thay ký tự Latin bằng Cyrillic homoglyph."""
    full_msg = message + DELIMITER
    bits = text_to_bits(full_msg)

    # Tìm vị trí các ký tự có homoglyph
    positions = [(i, ch) for i, ch in enumerate(cover_text) if ch in LATIN_TO_CYRILLIC]

    if len(bits) > len(positions):
        print(f"[ERROR] Không đủ ký tự homoglyph! Cần {len(bits)}, có {len(positions)}")
        sys.exit(1)

    result = list(cover_text)
    for idx, bit in enumerate(bits):
        pos, latin_ch = positions[idx]
        if bit == 1:
            result[pos] = LATIN_TO_CYRILLIC[latin_ch]  # Thay bằng Cyrillic

    return ''.join(result)

def main():
    parser = argparse.ArgumentParser(description='Homoglyph Embed')
    parser.add_argument('--input',   required=True, help='File cover text')
    parser.add_argument('--output',  required=True, help='File stego output')
    parser.add_argument('--message', required=True, help='Thông điệp bí mật')
    args = parser.parse_args()

    with open(args.input, 'r', encoding='utf-8') as f:
        cover = f.read()

    stego = embed_homoglyph(cover, args.message)

    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(stego)

    print(f"[SUCCESS] Đã lưu stego text: {args.output}")
    print(f"[INFO] Thông điệp: '{args.message}'")

if __name__ == '__main__':
    main()
