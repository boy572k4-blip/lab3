#!/usr/bin/env python3
"""
Zero-Width Character Steganography - Nhúng thông điệp vào văn bản
Sử dụng ZWSP (U+200B), ZWNJ (U+200C), ZWJ (U+200D) để mã hóa bit
  ZWSP = 0, ZWNJ = 1 (mỗi cặp ký tự encode 1 bit)
"""
import argparse
import sys

ZWSP = '\u200b'   # Zero Width Space  => bit 0
ZWNJ = '\u200c'   # Zero Width Non-Joiner => bit 1
ZWJ  = '\u200d'   # Zero Width Joiner (dùng làm separator giữa các byte)
DELIMITER = "$$END$$"

def text_to_bits(text):
    bits = []
    for ch in text:
        byte = ord(ch)
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    return bits

def embed_zwc(cover_text, message):
    """Nhúng message vào cover_text bằng cách chèn ZWC sau mỗi space/newline."""
    full_msg = message + DELIMITER
    bits = text_to_bits(full_msg)

    # Tìm các vị trí có thể chèn (sau space hoặc dấu chấm câu)
    positions = []
    for i, ch in enumerate(cover_text):
        if ch in (' ', '\t', '.', ',', '!', '?', '\n'):
            positions.append(i + 1)

    if len(bits) > len(positions):
        print(f"[ERROR] Cover text quá ngắn! Cần {len(bits)} vị trí, có {len(positions)}")
        sys.exit(1)

    result = list(cover_text)
    # Chèn ngược để không làm lệch index
    insertions = []
    for idx, bit in enumerate(bits):
        pos = positions[idx]
        zwc = ZWSP if bit == 0 else ZWNJ
        insertions.append((pos, zwc))

    # Chèn từ cuối về đầu
    for pos, zwc in sorted(insertions, key=lambda x: x[0], reverse=True):
        result.insert(pos, zwc)

    return ''.join(result)

def main():
    parser = argparse.ArgumentParser(description='ZWC Embed - Nhúng thông điệp bằng Zero-Width Characters')
    parser.add_argument('--cover',   required=True, help='File văn bản cover')
    parser.add_argument('--output',  required=True, help='File stego output')
    parser.add_argument('--message', required=True, help='Thông điệp bí mật')
    args = parser.parse_args()

    with open(args.cover, 'r', encoding='utf-8') as f:
        cover = f.read()

    stego = embed_zwc(cover, args.message)

    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(stego)

    print(f"[SUCCESS] Đã nhúng thông điệp vào: {args.output}")
    print(f"[INFO] Thông điệp: '{args.message}'")
    print(f"[INFO] Độ dài thông điệp + delimiter: {len(args.message + DELIMITER)} ký tự = {len(args.message + DELIMITER)*8} bits")

if __name__ == '__main__':
    main()
