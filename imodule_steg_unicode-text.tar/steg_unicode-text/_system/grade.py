#!/usr/bin/env python3
"""
Grading script for steg_unicode-text lab.
Called by Labtainer instructor.py after extracting student artifacts.
Args: student_dir lab_name
"""
import os
import sys

def check_file_contains(student_dir, container, rel_path, keyword):
    """Kiểm tra file tồn tại và chứa keyword"""
    full_path = os.path.join(student_dir, container, 'home', 'ubuntu', rel_path)
    alt_path  = os.path.join(student_dir, container, rel_path)
    for path in [full_path, alt_path]:
        if os.path.isfile(path):
            try:
                content = open(path, encoding='utf-8').read()
                return keyword.lower() in content.lower()
            except Exception:
                pass
    return False

def main():
    if len(sys.argv) < 2:
        print("Usage: grade.py <student_dir>")
        sys.exit(1)

    student_dir = sys.argv[1]
    results = {}

    # Phần A
    results['zwsp_bytes'] = check_file_contains(
        student_dir, 'steg_unicode-text.writer.student',
        'unicode_lab/zwsp_bytes.txt', 'zwsp_hex')

    results['embed_count'] = check_file_contains(
        student_dir, 'steg_unicode-text.writer.student',
        'unicode_lab/embed_count.txt', 'total_hidden_chars')

    results['result_zwsp'] = check_file_contains(
        student_dir, 'steg_unicode-text.reader.student',
        'unicode_lab/result_zwsp.txt', 'zwsp_message')

    # Phần B
    results['homoglyph_found'] = check_file_contains(
        student_dir, 'steg_unicode-text.reader.student',
        'unicode_lab/homoglyph_found.txt', 'char1')

    results['diff_result'] = check_file_contains(
        student_dir, 'steg_unicode-text.writer.student',
        'unicode_lab/diff_result.txt', 'diff_visible')

    results['result_homoglyph'] = check_file_contains(
        student_dir, 'steg_unicode-text.reader.student',
        'unicode_lab/result_homoglyph.txt', 'homoglyph_message')

    labels = {
        'zwsp_bytes':       'A1 - Ghi zwsp_bytes.txt',
        'embed_count':      'A2 - Ghi embed_count.txt',
        'result_zwsp':      'A3 - Ghi result_zwsp.txt',
        'homoglyph_found':  'B1 - Ghi homoglyph_found.txt',
        'diff_result':      'B2 - Ghi diff_result.txt',
        'result_homoglyph': 'B3 - Ghi result_homoglyph.txt',
    }

    for key, label in labels.items():
        mark = 'Y' if results[key] else 'N'
        print(f' {mark} -  {label}')

if __name__ == '__main__':
    main()
